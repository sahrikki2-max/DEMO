import { defineConfig } from 'vite';
import { resolve } from 'path';

// Multi-page build: include both index.html and gallery.html as entry points
export default defineConfig({
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        gallery: resolve(__dirname, 'gallery.html'),
      },
    },
  },
});
