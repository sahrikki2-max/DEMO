/* ============================================================
   Nexora AI — script.js
   ------------------------------------------------------------
   Lightweight, dependency-free JavaScript.
   Modules:
   1.  Data (events + solutions + gallery images)
   2.  Footer year
   3.  Mobile navigation toggle
   4.  Active link highlighting on scroll
   5.  Reveal-on-scroll (IntersectionObserver)
   6.  Event cards + accordion + "Show All Events"
   7.  Solution cards + "Show All Solutions"
   8.  Gallery page grid + lightbox
   9.  Contact form validation
   10. Back-to-top button
   ============================================================ */

(function () {
  'use strict';

  /* ============================================================
     1. DATA
     ------------------------------------------------------------
     Centralized data keeps HTML clean and easy to maintain.
     Images use Pexels (royalty-free). Swap URLs to replace.
  ============================================================ */

  // 9 events: first 6 visible, last 3 hidden until "Show All"
  const EVENTS = [
    {
      img: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'AI Summit 2026',
      date: 'Mar 12, 2026',
      short: 'The flagship conference on applied artificial intelligence and enterprise transformation.',
      full: 'Join 2,000+ engineers, founders, and researchers for two days of keynotes, hands-on labs, and networking. Topics include large language models, responsible AI, and real-world deployment stories from leading companies.',
      time: '9:00 AM – 5:00 PM',
      location: 'Moscone Center, San Francisco',
      info: 'Early-bird tickets available. Includes workshop pass and networking dinner.'
    },
    {
      img: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Machine Learning Workshop',
      date: 'Apr 05, 2026',
      short: 'A hands-on workshop covering model training, evaluation, and deployment.',
      full: 'Bring your laptop and build a complete ML pipeline from scratch. We cover data preparation, feature engineering, model selection, and deployment with MLOps best practices. Suitable for intermediate developers.',
      time: '10:00 AM – 4:00 PM',
      location: 'Nexora HQ, San Francisco',
      info: 'Limited to 40 seats. Lunch and materials provided.'
    },
    {
      img: 'https://images.pexels.com/photos/796602/pexels-photo-796602.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Data Science Meetup',
      date: 'Apr 22, 2026',
      short: 'Monthly community meetup for data enthusiasts and practitioners.',
      full: 'An informal evening of lightning talks, project showcases, and community networking. Great for meeting peers, sharing work, and discovering new opportunities in the data science space.',
      time: '6:30 PM – 9:00 PM',
      location: 'Innovation Hub, San Francisco',
      info: 'Free entry. Walk-ins welcome. Light refreshments served.'
    },
    {
      img: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'AI Ethics Panel',
      date: 'May 10, 2026',
      short: 'A panel discussion on building responsible and fair AI systems.',
      full: 'Industry leaders discuss the ethical challenges of AI — bias, transparency, accountability, and regulation. Audience Q&A follows the panel. A must-attend for product leaders and policymakers.',
      time: '5:00 PM – 7:30 PM',
      location: 'Online (Virtual Event)',
      info: 'Free registration. Recording available to all registrants.'
    },
    {
      img: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Innovation Hackathon',
      date: 'Jun 01, 2026',
      short: '48 hours of building AI-powered solutions for real-world problems.',
      full: 'Form a team, pick a challenge, and build a working AI prototype over a weekend. Mentors, datasets, and compute credits provided. Top teams win prizes and the chance to pilot with partner companies.',
      time: 'Starts Friday 6:00 PM',
      location: 'Tech Campus, San Francisco',
      info: 'Teams of 2–5. Registration includes meals for the full weekend.'
    },
    {
      img: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Automation Expo',
      date: 'Jul 18, 2026',
      short: 'Showcasing the latest in intelligent automation and AI agents.',
      full: 'Explore live demos of automation platforms, AI agents, and workflow tools from leading vendors. Includes a vendor hall, demo stages, and curated talks on scaling automation across the enterprise.',
      time: '9:30 AM – 6:00 PM',
      location: 'Expo Center, San Jose',
      info: 'Exhibitor passes and group discounts available.'
    },
    // --- Hidden until "Show All Events" ---
    {
      img: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Deep Learning Bootcamp',
      date: 'Aug 08, 2026',
      short: 'An intensive 3-day bootcamp on neural networks and deep learning.',
      full: 'Go from fundamentals to advanced architectures — CNNs, RNNs, transformers, and beyond. Daily lectures paired with coding labs. Designed for developers who want a deep, practical understanding of modern deep learning.',
      time: '9:00 AM – 5:00 PM (3 days)',
      location: 'Nexora Training Center, San Francisco',
      info: 'Certificate of completion provided. Prerequisites: Python and basic ML.'
    },
    {
      img: 'https://images.pexels.com/photos/3184398/pexels-photo-3184398.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'AI in Healthcare Forum',
      date: 'Sep 15, 2026',
      short: 'Exploring AI applications transforming healthcare and life sciences.',
      full: 'Clinicians, researchers, and technologists share how AI is improving diagnostics, drug discovery, and patient outcomes. Includes case studies, regulatory insights, and a networking reception.',
      time: '8:30 AM – 4:00 PM',
      location: 'Medical Center, Boston',
      info: 'CME credits available for healthcare professionals.'
    },
    {
      img: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Startup AI Pitch Day',
      date: 'Oct 05, 2026',
      short: 'Early-stage AI startups pitch to investors and partners.',
      full: 'Watch 15 hand-picked AI startups pitch their vision to a room of investors and enterprise partners. Followed by a networking session for founders and funders. A great place to spot the next big thing in AI.',
      time: '2:00 PM – 6:00 PM',
      location: 'Venture Hub, San Francisco',
      info: 'Investor-only networking after 6:00 PM.'
    }
  ];

  // 12 solutions: first 6 visible, last 6 hidden until "Show All"
  const SOLUTIONS = [
    {
      img: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Vision',
      desc: 'Computer vision platform for image recognition, object detection, and visual quality inspection.'
    },
    {
      img: 'https://images.pexels.com/photos/8438922/pexels-photo-8438922.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Voice',
      desc: 'Speech-to-text, text-to-speech, and voice assistant APIs for natural voice interfaces.'
    },
    {
      img: 'https://images.pexels.com/photos/8728560/pexels-photo-8728560.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Chat',
      desc: 'Conversational AI and chatbot platform powered by large language models for customer support.'
    },
    {
      img: 'https://images.pexels.com/photos/8850806/pexels-photo-8850806.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Forecast',
      desc: 'Predictive analytics and forecasting engine for demand, revenue, and risk modeling.'
    },
    {
      img: 'https://images.pexels.com/photos/8386656/pexels-photo-8386656.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Automate',
      desc: 'Intelligent workflow automation with AI agents that handle repetitive business tasks.'
    },
    {
      img: 'https://images.pexels.com/photos/8439094/pexels-photo-8439094.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Insights',
      desc: 'Data analytics dashboard that turns raw business data into clear, actionable insights.'
    },
    // --- Hidden until "Show All Solutions" ---
    {
      img: 'https://images.pexels.com/photos/8728570/pexels-photo-8728570.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Detect',
      desc: 'Anomaly detection for fraud prevention, equipment monitoring, and security operations.'
    },
    {
      img: 'https://images.pexels.com/photos/8438918/pexels-photo-8438918.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Recommend',
      desc: 'Personalized recommendation engine for e-commerce, media, and content platforms.'
    },
    {
      img: 'https://images.pexels.com/photos/8386448/pexels-photo-8386448.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Translate',
      desc: 'Real-time neural machine translation supporting 100+ languages for global businesses.'
    },
    {
      img: 'https://images.pexels.com/photos/8439086/pexels-photo-8439086.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Search',
      desc: 'Semantic search and retrieval platform for documents, knowledge bases, and enterprise data.'
    },
    {
      img: 'https://images.pexels.com/photos/8728580/pexels-photo-8728580.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Document',
      desc: 'AI-powered document extraction and processing for invoices, contracts, and forms.'
    },
    {
      img: 'https://images.pexels.com/photos/8386664/pexels-photo-8386664.jpeg?auto=compress&cs=tinysrgb&w=600',
      title: 'Nexora Monitor',
      desc: 'Model monitoring and observability platform for tracking ML performance in production.'
    }
  ];

  // Gallery images (gallery.html)
  const GALLERY = [
    { src: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Audience at a technology conference', caption: 'AI Summit 2026 — Main Stage' },
    { src: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Speaker presenting at an AI event', caption: 'Keynote: The Future of Machine Learning' },
    { src: 'https://images.pexels.com/photos/796602/pexels-photo-796602.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Team workshop on machine learning', caption: 'Hands-on ML Workshop' },
    { src: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Networking at a tech summit', caption: 'Networking at the Automation Expo' },
    { src: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Panel discussion on AI ethics', caption: 'AI Ethics Panel Discussion' },
    { src: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Developers coding at a hackathon', caption: 'Innovation Hackathon — Build Session' },
    { src: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Deep learning bootcamp training', caption: 'Deep Learning Bootcamp' },
    { src: 'https://images.pexels.com/photos/3184398/pexels-photo-3184398.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Healthcare AI forum', caption: 'AI in Healthcare Forum' },
    { src: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Startup pitch day', caption: 'Startup AI Pitch Day' },
    { src: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Expo hall with vendors', caption: 'Automation Expo — Vendor Hall' },
    { src: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'AI research showcase', caption: 'Research Showcase Night' },
    { src: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1200', alt: 'Community meetup', caption: 'Monthly Data Science Meetup' }
  ];

  /* ============================================================
     2. FOOTER YEAR
  ============================================================ */
  function initFooterYear() {
    const yearEl = document.getElementById('year');
    if (yearEl) yearEl.textContent = new Date().getFullYear();
  }

  /* ============================================================
     3. MOBILE NAVIGATION TOGGLE
  ============================================================ */
  function initMobileNav() {
    const toggle = document.getElementById('navToggle');
    const list = document.getElementById('navList');
    if (!toggle || !list) return;

    toggle.addEventListener('click', () => {
      const open = list.classList.toggle('is-open');
      toggle.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });

    // Close menu when a link is clicked (mobile)
    list.addEventListener('click', (e) => {
      if (e.target.matches('a')) {
        list.classList.remove('is-open');
        toggle.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ============================================================
     4. ACTIVE LINK HIGHLIGHTING ON SCROLL
  ============================================================ */
  function initActiveLink() {
    const links = document.querySelectorAll('.nav__link');
    if (!links.length) return;

    // Map each link to its target section (only for in-page anchors)
    const sections = [];
    links.forEach((link) => {
      const href = link.getAttribute('href') || '';
      if (href.startsWith('#')) {
        const sec = document.querySelector(href);
        if (sec) sections.push({ link, sec });
      }
    });
    if (!sections.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            sections.forEach(({ link, sec }) => {
              link.classList.toggle('is-active', sec === entry.target);
            });
          }
        });
      },
      { rootMargin: '-45% 0px -50% 0px', threshold: 0 }
    );

    sections.forEach(({ sec }) => observer.observe(sec));
  }

  /* ============================================================
     5. REVEAL-ON-SCROLL
  ============================================================ */
  function initReveal() {
    const reveals = document.querySelectorAll('.reveal');
    if (!reveals.length) return;

    // Fallback: if IntersectionObserver unsupported, show everything
    if (!('IntersectionObserver' in window)) {
      reveals.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    reveals.forEach((el) => observer.observe(el));
  }

  /* ============================================================
     6. EVENT CARDS + ACCORDION + SHOW ALL
  ============================================================ */
  function renderEventCard(event, index) {
    const hiddenClass = index >= 6 ? ' is-hidden' : '';
    return `
      <article class="event-card${hiddenClass}" data-index="${index}">
        <img class="event-card__media" src="${event.img}" alt="${event.title}" loading="lazy" width="600" height="180" />
        <div class="event-card__body">
          <p class="event-card__date">${event.date}</p>
          <h3 class="event-card__title">${event.title}</h3>
          <p class="event-card__desc">${event.short}</p>
          <button class="event-card__toggle" type="button" aria-expanded="false">
            View Details
            <span class="event-card__toggle-icon" aria-hidden="true">&#9662;</span>
          </button>
        </div>
        <div class="event-card__panel">
          <img class="event-card__panel-img" src="${event.img.replace('w=600', 'w=900')}" alt="${event.title}" loading="lazy" />
          <ul class="event-card__meta">
            <li><strong>Date:</strong> ${event.date}</li>
            <li><strong>Time:</strong> ${event.time}</li>
            <li><strong>Location:</strong> ${event.location}</li>
          </ul>
          <p class="event-card__full">${event.full}</p>
          <p class="event-card__full" style="margin-top:0.5rem"><strong>Info:</strong> ${event.info}</p>
        </div>
      </article>`;
  }

  function initEvents() {
    const grid = document.getElementById('eventsGrid');
    if (!grid) return;

    // Inject all 9 cards (last 3 hidden via class)
    grid.innerHTML = EVENTS.map((ev, i) => renderEventCard(ev, i)).join('');

    // Accordion: toggle a card's expanded panel
    grid.addEventListener('click', (e) => {
      const toggleBtn = e.target.closest('.event-card__toggle');
      if (!toggleBtn) return;

      const card = toggleBtn.closest('.event-card');
      const open = card.classList.toggle('is-open');
      toggleBtn.setAttribute('aria-expanded', String(open));
      toggleBtn.firstChild.textContent = open ? 'Show Less ' : 'View Details ';
    });

    // "Show All Events" reveals the 3 hidden cards
    const showBtn = document.getElementById('showAllEvents');
    if (showBtn) {
      showBtn.addEventListener('click', () => {
        const hidden = grid.querySelectorAll('.event-card.is-hidden');
        const revealing = hidden.length > 0;

        hidden.forEach((card, i) => {
          card.classList.remove('is-hidden');
          card.classList.add('is-revealing');
          // Stagger the fade-in slightly
          card.style.animationDelay = `${i * 0.08}s`;
        });

        if (revealing) {
          showBtn.textContent = 'Show Less Events';
          showBtn.setAttribute('aria-expanded', 'true');
        } else {
          // Re-hide the extra cards
          grid.querySelectorAll('.event-card').forEach((card, i) => {
            if (i >= 6) {
              card.classList.add('is-hidden');
              card.classList.remove('is-open');
              card.classList.remove('is-revealing');
              card.style.animationDelay = '';
              const btn = card.querySelector('.event-card__toggle');
              if (btn) {
                btn.setAttribute('aria-expanded', 'false');
                btn.firstChild.textContent = 'View Details ';
              }
            }
          });
          showBtn.textContent = 'Show All Events';
          showBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }
  }

  /* ============================================================
     7. SOLUTION CARDS + SHOW ALL
  ============================================================ */
  function renderSolutionCard(sol, index) {
    const hiddenClass = index >= 6 ? ' is-hidden' : '';
    return `
      <article class="solution-card${hiddenClass}">
        <img class="solution-card__img" src="${sol.img}" alt="${sol.title}" loading="lazy" width="600" height="180" />
        <div class="solution-card__body">
          <h3 class="solution-card__title">${sol.title}</h3>
          <p class="solution-card__desc">${sol.desc}</p>
          <button class="btn btn--ghost" type="button">Learn More</button>
        </div>
      </article>`;
  }

  function initSolutions() {
    const grid = document.getElementById('ourSolutionsGrid');
    if (!grid) return;

    grid.innerHTML = SOLUTIONS.map((sol, i) => renderSolutionCard(sol, i)).join('');

    const showBtn = document.getElementById('showAllSolutions');
    if (!showBtn) return;

    showBtn.addEventListener('click', () => {
      const hidden = grid.querySelectorAll('.solution-card.is-hidden');
      const revealing = hidden.length > 0;

      hidden.forEach((card, i) => {
        card.classList.remove('is-hidden');
        card.classList.add('is-revealing');
        card.style.animationDelay = `${i * 0.08}s`;
      });

      if (revealing) {
        showBtn.textContent = 'Show Less Solutions';
        showBtn.setAttribute('aria-expanded', 'true');
      } else {
        grid.querySelectorAll('.solution-card').forEach((card, i) => {
          if (i >= 6) {
            card.classList.add('is-hidden');
            card.classList.remove('is-revealing');
            card.style.animationDelay = '';
          }
        });
        showBtn.textContent = 'Show All Solutions';
        showBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ============================================================
     8. GALLERY PAGE GRID + LIGHTBOX
  ============================================================ */
  function initGallery() {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;

    // Build gallery items
    grid.innerHTML = GALLERY.map(
      (g, i) => `
        <button class="gallery__item" data-index="${i}" aria-label="Open image: ${g.caption}">
          <img src="${g.src.replace('w=1200', 'w=600')}" alt="${g.alt}" loading="lazy" width="600" height="260" />
        </button>`
    ).join('');

    const lightbox = document.getElementById('lightbox');
    const lbImg = document.getElementById('lightboxImg');
    const lbCaption = document.getElementById('lightboxCaption');
    const lbClose = document.getElementById('lightboxClose');
    const lbPrev = document.getElementById('lightboxPrev');
    const lbNext = document.getElementById('lightboxNext');
    let currentIndex = 0;

    if (!lightbox || !lbImg) return;

    function showImage(index) {
      currentIndex = (index + GALLERY.length) % GALLERY.length;
      const item = GALLERY[currentIndex];
      lbImg.src = item.src;
      lbImg.alt = item.alt;
      lbCaption.textContent = item.caption;
    }

    function openLightbox(index) {
      showImage(index);
      lightbox.hidden = false;
      document.body.style.overflow = 'hidden';
      lbClose.focus();
    }

    function closeLightbox() {
      lightbox.hidden = true;
      document.body.style.overflow = '';
    }

    // Open on item click
    grid.addEventListener('click', (e) => {
      const item = e.target.closest('.gallery__item');
      if (!item) return;
      openLightbox(parseInt(item.dataset.index, 10));
    });

    // Controls
    lbClose.addEventListener('click', closeLightbox);
    lbPrev.addEventListener('click', () => showImage(currentIndex - 1));
    lbNext.addEventListener('click', () => showImage(currentIndex + 1));

    // Click backdrop to close
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLightbox();
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (lightbox.hidden) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
      if (e.key === 'ArrowRight') showImage(currentIndex + 1);
    });
  }

  /* ============================================================
     9. CONTACT FORM VALIDATION
  ============================================================ */
  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const status = document.getElementById('formStatus');

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      // Use native validity check
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      // Simulate a successful submission (no backend in this static project)
      status.textContent = 'Thank you! Your message has been sent. We will get back to you soon.';
      form.reset();

      // Clear status after a few seconds
      setTimeout(() => {
        if (status) status.textContent = '';
      }, 6000);
    });
  }

  /* ============================================================
     10. BACK TO TOP
  ============================================================ */
  function initBackToTop() {
    const btn = document.getElementById('toTop');
    if (!btn) return;

    const toggleVisibility = () => {
      const show = window.scrollY > 500;
      btn.hidden = false;
      btn.classList.toggle('is-visible', show);
      if (!show) btn.blur();
    };

    // Use passive listener for scroll performance
    window.addEventListener('scroll', toggleVisibility, { passive: true });
    toggleVisibility();

    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ============================================================
     INIT — run after DOM is ready
  ============================================================ */
  function init() {
    initFooterYear();
    initMobileNav();
    initActiveLink();
    initReveal();
    initEvents();
    initSolutions();
    initGallery();
    initContactForm();
    initBackToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
